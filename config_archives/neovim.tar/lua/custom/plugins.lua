-- In order to modify the `lspconfig` configuration:
local plugins ={
  "neovim/nvim-lspconfig",
   config = function()
      require "plugins.configs.lspconfig"
      require "custom.configs.lspconfig"
   end,
}
return plugins

